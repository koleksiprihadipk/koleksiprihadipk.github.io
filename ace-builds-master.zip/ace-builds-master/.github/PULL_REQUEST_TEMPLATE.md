<!--
Most of the files here are generated with a build script, so You probably
should submit your pull request to https://github.com/ajaxorg/ace instead
-->

*Issue #, if available:*

*Description of changes:*


By submitting this pull request, I confirm that you can use, modify, copy, and redistribute this contribution, under the terms of your choice.
